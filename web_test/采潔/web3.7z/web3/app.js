var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
//------------------------------------------------------------
// �W�[�ޥμҲ�
//------------------------------------------------------------
var product_list = require('./routes/product_list');
var product_one = require('./routes/product_one');
var product_page = require('./routes/product_page');
var product_query_form = require('./routes/product_query_form');
var product_query = require('./routes/product_query');
var product_add_form = require('./routes/product_add_form');
var product_add = require('./routes/product_add');
var product_remove_form = require('./routes/product_remove_form');
var product_remove = require('./routes/product_remove');
var product_update_no = require('./routes/product_update_no');
var product_update_form = require('./routes/product_update_form');
var product_update = require('./routes/product_update');
//------------------------------------------------------------

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
//-----------------------------------------
// �]�w�ҲըϥΤ覡
//-----------------------------------------
app.use('/product/list', product_list);
app.use('/product/one', product_one);
app.use('/product/page', product_page);
app.use('/product/query/form', product_query_form);
app.use('/product/query', product_query);
app.use('/product/add/form', product_add_form);
app.use('/product/add', product_add);
app.use('/product/remove/form', product_remove_form);
app.use('/product/remove', product_remove);
app.use('/product/update/no', product_update_no);
app.use('/product/update/form', product_update_form);
app.use('/product/update', product_update);
//-----------------------------------------

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
});

module.exports = app;
