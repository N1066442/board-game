var express = require('express');
var router = express.Router();

//�W�[�ޥΨ禡
var moment = require('moment');
const product = require('./utility/product');

//����GET�ШD
router.get('/', function (req, res, next) {
    var prono = req.query.prono;   //���X�Ѽ�

    product.query(prono).then(data => {
        if (data == null) {
            res.render('error');  //�ɦV���~����
        } else if (data == -1) {
            res.render('notFound');  //�ɦV�䤣�쭶��                
        } else {
            data.inventorydate = moment(data.inventorydate).format("YYYY-MM-DD")
            res.render('product_query', { item: data });  //�N��ƶǵ���ܭ���
        }
    })
});

module.exports = router;