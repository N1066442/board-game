var express = require('express');
var router = express.Router();

//�W�[�ޥΨ禡
var moment = require('moment');
const product = require('./utility/product');

//����GET�ШD
router.get('/', function (req, res, next) {
    var no = req.query.prono;

    product.query(no).then(d => {
        if (d != null && d != -1) {
            var data = {
                prono: d.prono,
                proname: d.proname,
                price: d.price,
                inventorydate: moment(d.inventorydate).format("YYYY-MM-DD")
            }

            res.render('product_update_form', { item: data });  //�N��ƶǵ���s����
        } else {
            res.render('notFound');  //�ɦV�䤣�쭶��
        }
    })
});

//�ץX
module.exports = router;