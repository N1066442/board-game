'use strict';

//�ޥξާ@��Ʈw������
const sql = require('./asyncDB');

//------------------------------------------
//�����Ʈw�ʧ@���禡-�Ǧ^�Ҧ����~���
//------------------------------------------
var list = async function () {
    var result = [];

    await sql('SELECT * FROM product ORDER BY prono')
        .then((data) => {
            result = data.rows;
        }, (error) => {
            result = null;
        });

    return result;
}

//------------------------------------------
//�����Ʈw�ʧ@���禡-���X��@�ӫ~
//------------------------------------------
var one = async function (prono) {
    var result = {};

    await sql('SELECT * FROM product WHERE prono = $1', [prono])
        .then((data) => {
            if (data.rows.length > 0) {
                result = data.rows[0];
            } else {
                result = -1;
            }
        }, (error) => {
            result = null;
        });

    return result;
}

//---------------------------------------------
//�����Ʈw�ʧ@���禡-�Ǧ^�����Ϋ��w���������~
//---------------------------------------------
var page = async function (pageNo) {
    const linePerPage = 15;    //�]�w�C����Ƶ���
    const navSegments = 10;    //�]�w�����C��ܤ�����
    const startPage = Math.floor((pageNo - 1) / navSegments) * navSegments + 1;  //�p������C���_�l����

    var totalLine, totalPage;
    var result = {};

    await sql('SELECT count(*) AS cnt FROM product')
        .then((data) => {
            totalLine = data.rows[0].cnt;
            totalPage = Math.ceil(totalLine / linePerPage);
        }, (error) => {
            totalLine = 0;
            totalPage = 0;
        });

    await sql('SELECT * FROM product ORDER BY prono LIMIT $2 OFFSET $1', [(pageNo - 1) * linePerPage, linePerPage])
        .then((data) => {
            result = { data: data.rows, pageNo: pageNo, totalLine: totalLine, totalPage: totalPage, startPage: startPage, linePerPage: linePerPage, navSegments: navSegments };
        }, (error) => {
            result = null;
        });

    return result;
}

//------------------------------------------
//�����Ʈw�ʧ@���禡-���X��@�ӫ~
//------------------------------------------
var query = async function (prono) {
    var result = {};

    await sql('SELECT * FROM product WHERE prono = $1', [prono])
        .then((data) => {
            if (data.rows.length > 0) {
                result = data.rows[0];
            } else {
                result = -1;
            }
        }, (error) => {
            result = null;
        });

    return result;
}

//------------------------------------------
//�����Ʈw�ʧ@���禡-�s�W���~���
//------------------------------------------
var add = async function (newData) {
    var result;

    await sql('INSERT INTO product (prono, proname, price, inventorydate) VALUES ($1, $2, $3, $4)', [newData.prono, newData.proname, newData.price, newData.inventorydate])
        .then((data) => {
            result = 0;
        }, (error) => {
            result = -1;
        });

    return result;
}

//------------------------------------------
// ���X���A���
//------------------------------------------
var getDropdownData = async function () {
    //�x�s�U�Ԧ������
    var protype;

    //���^protype���
    await sql('SELECT * FROM protype ORDER BY typno')
        .then((data) => {
            protype = data.rows;
        }, (error) => {
            result = [];
        });

    //�]�w�^�Ǹ��    
    var result = {};
    result.protype = protype;

    //�^��
    return result;
}

//----------------------------------
// �R���ӫ~
//----------------------------------
var remove = async function (prono) {
    var result;

    await sql('DELETE FROM product WHERE prono = $1', [prono])
        .then((data) => {
            result = data.rowCount;
        }, (error) => {
            result = -1;
        });

    return result;
}

//----------------------------------
// ��s�ӫ~
//----------------------------------
var update = async function (newData) {
    var results;

    await sql('UPDATE product SET proname=$1, price=$2, inventorydate=$3 WHERE prono = $4', [newData.proname, newData.price, newData.inventorydate, newData.prono])
        .then((data) => {
            results = data.rowCount;
        }, (error) => {
            results = -1;
        });

    return results;
}

//�ץX
module.exports = { list, one, page, query, add, getDropdownData, remove, update};